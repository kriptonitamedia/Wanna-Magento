<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com/
-------------------------------------------------------------------------*/ 
class Magentothem_Themeoptions_Model_Config_Color
{

    public function toOptionArray()
    {
        return array(
            array('value'=>'red', 'label'=>Mage::helper('adminhtml')->__('red')),
            array('value'=>'green', 'label'=>Mage::helper('adminhtml')->__('green')),
            array('value'=>'orange', 'label'=>Mage::helper('adminhtml')->__('orange')),
            array('value'=>'blue', 'label'=>Mage::helper('adminhtml')->__('blue')),
            array('value'=>'purple', 'label'=>Mage::helper('adminhtml')->__('purple')),
            array('value'=>'sea_green', 'label'=>Mage::helper('adminhtml')->__('sea_green')),
            array('value'=>'dark_khaki', 'label'=>Mage::helper('adminhtml')->__('dark_khaki'))
        );
    }

}
