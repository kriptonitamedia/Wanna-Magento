<?php

class Magentothem_Themeoptions_Model_Config_Customfieldpattern
{

    public function toOptionArray()
    {
        return array(
            array('value'=>'pattern1','label' => Mage::helper('themeoptions')->__('Pattern 1')),
            array('value'=>'pattern2','label' => Mage::helper('themeoptions')->__('Pattern 2')),
            array('value'=>'pattern3','label' => Mage::helper('themeoptions')->__('Pattern 3')),
            array('value'=>'pattern4','label' => Mage::helper('themeoptions')->__('Pattern 4')),
            array('value'=>'pattern5','label' => Mage::helper('themeoptions')->__('Pattern 5')),
            array('value'=>'pattern6','label' => Mage::helper('themeoptions')->__('Pattern 6')),
            array('value'=>'pattern7','label' => Mage::helper('themeoptions')->__('Pattern 7')),
            array('value'=>'pattern8','label' => Mage::helper('themeoptions')->__('Pattern 8')),
            array('value'=>'pattern9','label' => Mage::helper('themeoptions')->__('Pattern 9')),
            array('value'=>'pattern10','label' => Mage::helper('themeoptions')->__('Pattern 10')),
            array('value'=>'pattern11','label' => Mage::helper('themeoptions')->__('Pattern 11')),
            array('value'=>'pattern12','label' => Mage::helper('themeoptions')->__('Pattern 12')),
            array('value'=>'pattern13','label' => Mage::helper('themeoptions')->__('Pattern 13')),
            array('value'=>'pattern14','label' => Mage::helper('themeoptions')->__('Pattern 14')),
            array('value'=>'pattern15','label' => Mage::helper('themeoptions')->__('Pattern 15')),
            array('value'=>'pattern16','label' => Mage::helper('themeoptions')->__('Pattern 16')),
            array('value'=>'pattern17','label' => Mage::helper('themeoptions')->__('Pattern 17')),
            array('value'=>'pattern18','label' => Mage::helper('themeoptions')->__('Pattern 18')),
            array('value'=>'pattern19','label' => Mage::helper('themeoptions')->__('Pattern 19')),
            array('value'=>'pattern20','label' => Mage::helper('themeoptions')->__('Pattern 20')),
            array('value'=>'pattern21','label' => Mage::helper('themeoptions')->__('Pattern 21')),
            array('value'=>'pattern22','label' => Mage::helper('themeoptions')->__('Pattern 22')),
            array('value'=>'pattern23','label' => Mage::helper('themeoptions')->__('Pattern 23')),
            array('value'=>'pattern24','label' => Mage::helper('themeoptions')->__('Pattern 24')),
            array('value'=>'pattern25','label' => Mage::helper('themeoptions')->__('Pattern 25')),
            array('value'=>'pattern26','label' => Mage::helper('themeoptions')->__('Pattern 26')),
            array('value'=>'pattern27','label' => Mage::helper('themeoptions')->__('Pattern 27')),
            array('value'=>'pattern28','label' => Mage::helper('themeoptions')->__('Pattern 28')),
            array('value'=>'pattern29','label' => Mage::helper('themeoptions')->__('Pattern 29')),
            array('value'=>'pattern30','label' => Mage::helper('themeoptions')->__('Pattern 30')),
			array('value'=>'',       'label' => Mage::helper('themeoptions')->__('Without pattern')),
        );
    }

}
